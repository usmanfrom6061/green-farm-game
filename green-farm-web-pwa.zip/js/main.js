const config = {
  type: Phaser.AUTO,
  width: 320,
  height: 240,
  pixelArt: true,
  backgroundColor: '#6bbf59',
  parent: 'game',
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH
  },
  scene: {
    create,
    update
  }
};

// shared movement state, driven by keyboard OR on-screen touch buttons
const move = { left: false, right: false, up: false, down: false };

function create() {
  this.add.text(40, 20, 'Green Farm Web', { font: '16px Arial', color: '#ffffff' });
  this.player = this.add.rectangle(160, 120, 16, 16, 0xff0000);
  this.cursors = this.input.keyboard.createCursorKeys();
}

function update() {
  const s = 2;
  if (this.cursors.left.isDown || move.left) this.player.x -= s;
  if (this.cursors.right.isDown || move.right) this.player.x += s;
  if (this.cursors.up.isDown || move.up) this.player.y -= s;
  if (this.cursors.down.isDown || move.down) this.player.y += s;
}

new Phaser.Game(config);

// --- on-screen touch controls (only matter on touch devices, harmless on desktop) ---
function buildTouchControls() {
  const wrap = document.getElementById('touch-controls');
  const layout = [
    { key: 'up', label: '▲', row: 1, col: 2 },
    { key: 'left', label: '◀', row: 2, col: 1 },
    { key: 'down', label: '▼', row: 2, col: 2 },
    { key: 'right', label: '▶', row: 2, col: 3 }
  ];

  layout.forEach(({ key, label, row, col }) => {
    const btn = document.createElement('button');
    btn.className = 'ctrl-btn';
    btn.textContent = label;
    btn.style.gridRow = row;
    btn.style.gridColumn = col;

    const setActive = (v) => (move[key] = v);
    const press = (e) => { e.preventDefault(); setActive(true); };
    const release = (e) => { e.preventDefault(); setActive(false); };

    btn.addEventListener('touchstart', press, { passive: false });
    btn.addEventListener('touchend', release, { passive: false });
    btn.addEventListener('touchcancel', release, { passive: false });
    // also support mouse for desktop testing
    btn.addEventListener('mousedown', press);
    btn.addEventListener('mouseup', release);
    btn.addEventListener('mouseleave', release);

    wrap.appendChild(btn);
  });
}

buildTouchControls();
